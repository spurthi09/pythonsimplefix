import simplefix
import message
fix_msg = simplefix.Message()
#print fix_msg
