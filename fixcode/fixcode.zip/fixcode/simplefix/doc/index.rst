.. Master documentation file

SimpleFIX
=========

.. toctree::
    :maxdepth: 2
    :caption: Contents:

    intro
    getting
    import
    creating
    encoding
    parsing

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
